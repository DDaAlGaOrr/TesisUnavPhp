<?php
   define('DB_SERVER', 'localhost');
   define('DB_USERNAME', 'root');
   define('DB_PASSWORD', 'root');
   define('DB_DATABASE', 'biblio_impresiones');
   $db = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

   // Check connection
if (mysqli_connect_errno())
  {
  echo "Fallo al connectar  MySQL: " . mysqli_connect_error();
  }
?>